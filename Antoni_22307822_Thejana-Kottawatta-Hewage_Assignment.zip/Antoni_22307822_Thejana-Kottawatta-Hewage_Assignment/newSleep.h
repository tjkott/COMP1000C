#ifndef NEWSLEEP_H
#define NEWSLEEP_H

void newSleep(float sec);

#endif
